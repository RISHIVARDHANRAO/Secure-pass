package com.rishi.generatepass;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends Activity {

    TextView tv, lengthLabel;
    Button genBtn, copyBtn;
    Spinner strengthSpinner;
    SeekBar lengthSeekBar;
    Switch darkSwitch;
    LinearLayout rootLayout;
    SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tv = findViewById(R.id.tv);
        lengthLabel = findViewById(R.id.lengthLabel);
        genBtn = findViewById(R.id.btnGenerate);
        copyBtn = findViewById(R.id.btnCopy);
        strengthSpinner = findViewById(R.id.spinner);
        lengthSeekBar = findViewById(R.id.seekBar);
        darkSwitch = findViewById(R.id.darkSwitch);
        rootLayout = findViewById(R.id.rootLayout);

        prefs = getSharedPreferences("settings", MODE_PRIVATE);
        boolean isDarkMode = prefs.getBoolean("dark", false);

        String[] strengths = {"Easy", "Medium", "Strong"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, strengths);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        strengthSpinner.setAdapter(adapter);

        lengthSeekBar.setMax(24);
        lengthSeekBar.setProgress(12);
        lengthLabel.setText("Length: 12");

        lengthSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
				@Override
				public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
					int len = progress < 4 ? 4 : progress;
					lengthLabel.setText("Length: " + len);
				}

				@Override
				public void onStartTrackingTouch(SeekBar seekBar) {}

				@Override
				public void onStopTrackingTouch(SeekBar seekBar) {}
			});

        darkSwitch.setChecked(isDarkMode);
        applyTheme(isDarkMode);

        darkSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					prefs.edit().putBoolean("dark", isChecked).apply();
					applyTheme(isChecked);
				}
			});

        genBtn.setOnClickListener(new Button.OnClickListener() {
				@Override
				public void onClick(android.view.View v) {
					int length = lengthSeekBar.getProgress();
					if (length < 4) length = 4;
					String level = strengthSpinner.getSelectedItem().toString();
					String password = generatePassword(length, level);
					tv.setText(password);
				}
			});

        copyBtn.setOnClickListener(new Button.OnClickListener() {
				@Override
				public void onClick(android.view.View v) {
					String text = tv.getText().toString();
					ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
					if (cm != null) {
						cm.setPrimaryClip(ClipData.newPlainText("password", text));
						Toast.makeText(MainActivity.this, "Copied to clipboard", Toast.LENGTH_SHORT).show();
					} else {
						Toast.makeText(MainActivity.this, "Clipboard error", Toast.LENGTH_SHORT).show();
					}
				}
			});
    }

    private void applyTheme(boolean dark) {
        int bgColor = dark ? 0xFF121212 : 0xFFFFFFFF;
        int fgColor = dark ? 0xFFFFFFFF : 0xFF000000;

        rootLayout.setBackgroundColor(bgColor);
        tv.setTextColor(fgColor);
        lengthLabel.setTextColor(fgColor);
        darkSwitch.setTextColor(fgColor);
        genBtn.setTextColor(fgColor);
        copyBtn.setTextColor(fgColor);
        strengthSpinner.setBackgroundColor(dark ? 0xFF333333 : 0xFFFFFFFF);
    }

    private String generatePassword(int length, String strength) {
        String easy = "abcdefghijklmnopqrstuvwxyz";
        String medium = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        String strong = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_+-=[]{}";

        String chars;
        switch (strength) {
            case "Easy":
                chars = easy;
                break;
            case "Medium":
                chars = medium;
                break;
            case "Strong":
            default:
                chars = strong;
                break;
        }

        StringBuilder sb = new StringBuilder();
        Random rand = new Random();
        for (int i = 0; i < length; i++) {
            int idx = rand.nextInt(chars.length());
            sb.append(chars.charAt(idx));
        }
        return sb.toString();
    }
}
